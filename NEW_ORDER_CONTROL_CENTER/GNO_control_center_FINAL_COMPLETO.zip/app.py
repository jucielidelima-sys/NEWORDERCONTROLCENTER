import os
import runpy
from pathlib import Path
import streamlit as st

BASE_DIR = Path(__file__).parent
LEGACY_DIR = BASE_DIR / "legacy_apps"

st.set_page_config(
    page_title="NEW ORDER CONTROL CENTER",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded",
)

def inject_global_theme():
    st.markdown(
        '''
        <style>
        .stApp {
            background:
                radial-gradient(circle at 10% 10%, rgba(255,102,0,0.10), transparent 20%),
                radial-gradient(circle at 90% 15%, rgba(0,190,255,0.08), transparent 20%),
                linear-gradient(135deg, #0b0f14 0%, #111821 45%, #0e1319 100%);
            color: #ecf2f8;
        }
        section[data-testid="stSidebar"] {
            background: linear-gradient(180deg, #0c1015 0%, #141a22 100%);
            border-right: 1px solid rgba(255,255,255,0.08);
        }
        .hero {
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 28px;
            padding: 28px 30px;
            background:
                linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.03)),
                linear-gradient(135deg, rgba(255,102,0,0.06), rgba(0,190,255,0.04));
            box-shadow:
                0 18px 40px rgba(0,0,0,0.35),
                inset 0 1px 0 rgba(255,255,255,0.10),
                0 0 24px rgba(255,102,0,0.08);
            overflow: hidden;
            position: relative;
        }
        .hero-title {
            font-size: 40px;
            font-weight: 900;
            letter-spacing: 1px;
            margin: 0;
            color: #ffffff;
        }
        .hero-sub {
            font-size: 14px;
            color: #b9c4d1;
            margin-top: 6px;
            text-transform: uppercase;
            letter-spacing: 1.2px;
        }
        .mod-card {
            border-radius: 22px;
            padding: 18px;
            min-height: 138px;
            background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.025));
            border: 1px solid rgba(255,255,255,0.08);
            box-shadow: 0 10px 28px rgba(0,0,0,0.24);
        }
        .mod-title {
            color: #ffffff;
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
        }
        .mod-desc {
            color: #aeb8c6;
            font-size: 13px;
            line-height: 1.45;
        }
        .kpi {
            border-radius: 18px;
            padding: 16px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.08);
            margin-bottom: 10px;
        }
        .kpi-lbl { color:#aeb8c6; font-size:12px; text-transform: uppercase; font-weight:700; }
        .kpi-val { color:#fff; font-size:28px; font-weight:900; margin-top:4px; }
        </style>
        ''',
        unsafe_allow_html=True
    )

def run_legacy_app(path: Path):
    original_cwd = Path.cwd()
    original_fn = st.set_page_config
    try:
        os.chdir(path.parent)
        st.set_page_config = lambda *args, **kwargs: None
        runpy.run_path(str(path), run_name="__main__")
    finally:
        st.set_page_config = original_fn
        os.chdir(original_cwd)

def home():
    st.image(str(BASE_DIR / "legacy_apps" / "producao" / "logo.png"), width=220)
    st.markdown(
        '''
        <div class="hero">
            <div class="hero-title">NEW ORDER CONTROL CENTER</div>
            <div class="hero-sub">Plataforma industrial integrada • nível sala de controle</div>
        </div>
        ''',
        unsafe_allow_html=True
    )
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown('<div class="kpi"><div class="kpi-lbl">Módulos reais integrados</div><div class="kpi-val">3</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="kpi"><div class="kpi-lbl">Identidade visual</div><div class="kpi-val">GNO</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown('<div class="kpi"><div class="kpi-lbl">Status</div><div class="kpi-val">Fase 2</div></div>', unsafe_allow_html=True)

    a,b,c = st.columns(3)
    with a:
        st.markdown('<div class="mod-card"><div class="mod-title">Produção</div><div class="mod-desc">Dashboard completo com produtividade, tendência, forecast x produzido x faturado e rankings.</div></div>', unsafe_allow_html=True)
    with b:
        st.markdown('<div class="mod-card"><div class="mod-title">Plano de Ação Fábrica</div><div class="mod-desc">Gemba Board ANDON com KPIs, velocímetros, Pareto, Kanban e exportação.</div></div>', unsafe_allow_html=True)
    with c:
        st.markdown('<div class="mod-card"><div class="mod-title">Carga Máquina</div><div class="mod-desc">Dashboard MES industrial com gargalo matemático real, M.O, indiretos e simulação de cenários.</div></div>', unsafe_allow_html=True)

    st.info("Use o menu lateral para abrir cada módulo.")

inject_global_theme()
st.sidebar.image(str(BASE_DIR / "legacy_apps" / "producao" / "logo.png"), width=160)
st.sidebar.markdown("## GNO • Control Center")
menu = st.sidebar.radio(
    "Navegação",
    ["Home", "Produção", "Plano de Ação Fábrica", "Carga Máquina"]
)

if menu == "Home":
    home()
elif menu == "Produção":
    run_legacy_app(LEGACY_DIR / "producao" / "app.py")
elif menu == "Plano de Ação Fábrica":
    run_legacy_app(LEGACY_DIR / "pa" / "app.py")
elif menu == "Carga Máquina":
    app_path = LEGACY_DIR / "carga_maquina" / "app.py"
    excel_path = LEGACY_DIR / "carga_maquina" / "CG BOT PY.xlsx"
    if not app_path.exists():
        st.error("O código do módulo Carga Máquina não foi encontrado.")
    elif not excel_path.exists():
        st.warning("O código do módulo Carga Máquina foi integrado, mas o arquivo 'CG BOT PY.xlsx' ainda não está na pasta do módulo.")
        st.write("Coloque aqui:")
        st.code("legacy_apps/carga_maquina/CG BOT PY.xlsx")
        st.write("Assim que o Excel estiver na pasta, o módulo abre pelo launcher automaticamente.")
    else:
        run_legacy_app(app_path)
